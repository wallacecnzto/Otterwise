/*1 - [REFATORAÇÃO] Dado um array de nomes, faça um programa que imprima
na tela todos os nomes (na mesma linha).

entrada ['Angela', 'Rosa', 'Ticiana', 'Carla', 'Renata']
saida Angela, Rosa, Ticiana, Carla, Renata
*/

const array = ['Angela', 'Rosa', 'Ticiana', 'Carla', 'Renata']

console.log(array.join(" , "))
