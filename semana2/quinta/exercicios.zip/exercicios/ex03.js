// 3 - Dado um array de nomes, faça um programa que imprima na tela todos os
// nomes (na mesma linha).

let arrayOfNames = ['Maria', 'Jose', 'Joao', 'Pedro']

for(let i = 0; i < arrayOfNames.length; i++){
	console.log(arrayOfNames[i])
	console.log(typeof(arrayOfNames))
}
