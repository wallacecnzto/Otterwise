// 1 - Imprima no console os valores de 1 até 25.


for(let i = 1 ; i <= 25 ; i++){
	console.log(i)
}
