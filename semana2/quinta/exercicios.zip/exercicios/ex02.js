// 2 - Imprima no console os valores de 10 até 200 de 10 em 10.

for(let i = 10; i <= 200; i+=10){
	console.log(i);
}
