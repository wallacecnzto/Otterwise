/*
	*8 - Escreva um programa que tenham como entrada um valor. Este valor é a
	quantidade de linhas de saída que serão apresentadas na execução do
	programa.
	* */

const inputValue = 7



