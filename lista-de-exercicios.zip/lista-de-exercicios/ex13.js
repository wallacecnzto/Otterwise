let numero = 17

if(numero % 2 === 0) {
    console.log('Par')
}else {
    console.log('Impar')
}