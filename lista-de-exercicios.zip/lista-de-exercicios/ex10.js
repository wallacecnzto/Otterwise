let distanciaPercorrida = 240
let velocidade = 80
let combustivelGasto = 20

let tempoDeViagem = distanciaPercorrida / velocidade
let media = distanciaPercorrida / combustivelGasto

console.log('Média de consumo: ' + media + ' Km/l')
console.log('Tempo de viagem: ' + tempoDeViagem + ' horas')