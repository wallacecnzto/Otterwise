let nome = 'Wallace'
let sobrenome = 'Mariano'

console.log(nome + ' ' + sobrenome)