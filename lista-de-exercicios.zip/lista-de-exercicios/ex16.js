// Basta dividir o maior pelo menor,se a divisão for exata,eles são múltiplos entre si.

let valor1 = 10
let valor2 = 2

if(valor1 > valor2){
    
}
