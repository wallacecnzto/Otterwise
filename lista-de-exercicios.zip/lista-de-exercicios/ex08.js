let nome = 'Mariano'
let idade = 44

if (idade > 18) {
    console.log(nome + ' é maior de idade.')
} else {
    console.log(nome + ' é menor de idade.')
}
