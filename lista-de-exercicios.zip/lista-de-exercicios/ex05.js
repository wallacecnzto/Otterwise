let var1 = 10
let var2 = 5

let resultado = var1 + var2

console.log(resultado)