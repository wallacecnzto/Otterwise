const salarioFixo = 5000
let valorTotalVendido = 100000
let porcentagem = 10

let salarioTotal = salarioFixo + ((valorTotalVendido * porcentagem) / 100)

console.log(salarioTotal)