let valor1 = 25
let valor2 = 23

console.log(valor1 + '\n' + valor2)

aux = valor1
valor1 = valor2
valor2 = aux

console.log(valor1 + '\n' + valor2)