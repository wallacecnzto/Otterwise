let numero1 = 7
let numero2 = 7

if(numero1 > numero2) {
    console.log(numero1 + ' é maior que ' + numero2)
}else if( numero2 > numero1) {
    console.log(numero2 + ' é maior que ' + numero1)
} else {
    console.log(numero1 + ' é igual a ' + numero2)
}